-- Pure agent policy for the OpenAI Agent channel package.
--
-- This module is deliberately host-free: it operates only on plain Lua values
-- (already-decoded tables, strings, integers) so its bounds, conversation
-- construction, tool-schema/argument validation, effect-key derivation, and
-- response normalization can be unit-tested without any subspace.* surface.
-- JSON decoding/encoding and all I/O happen in the caller (agent/resolver),
-- which passes decoded tables in and receives normalized tables out.
--
-- Nothing here logs, persists, or formats secrets, prompts, transcripts, tool
-- arguments, or provider bodies. Normalized failure reasons are bounded enums.
local policy = {}

-- ---------------------------------------------------------------------------
-- Finite policy bounds (task 15.8: finite turns/calls/bytes/deadlines).
-- ---------------------------------------------------------------------------
policy.SCHEMA_VERSION = 1

-- Completion loop bounds for one Job.
policy.MAX_MODEL_TURNS = 8          -- maximum Chat Completion round-trips per Job
policy.MAX_TOOL_CALLS_TOTAL = 16    -- maximum keyboard tool effects per Job

-- Byte bounds for the values that cross into requests, effects, and payloads.
policy.MAX_SYSTEM_PROMPT_BYTES = 16384
policy.MAX_USER_TEXT_BYTES = 4096
policy.MAX_MODEL_ID_BYTES = 256
policy.MAX_BASE_URL_BYTES = 2048
policy.MAX_API_KEY_BYTES = 4096
policy.MAX_TOOL_TEXT_BYTES = 4096   -- type_text argument bound
policy.MAX_TOOL_RESULT_BYTES = 512  -- model-visible tool result content
policy.MAX_CALL_ID_BYTES = 256
policy.MAX_ASSISTANT_CONTENT_BYTES = 65536
policy.MAX_REASON_BYTES = 128

-- Provider/tool identity.
policy.TOOL_TYPE_TEXT = "type_text"
policy.TOOL_PRESS_ENTER = "press_enter"
policy.ENTER_KEY = "enter"

-- Normalized tool outcome classes (model-visible, bounded).
policy.OUTCOME_DELIVERED = "delivered"
policy.OUTCOME_REJECTED = "rejected"
policy.OUTCOME_FAILED = "failed"
policy.OUTCOME_INDETERMINATE = "indeterminate"

-- Bounded application failure reasons (never carry content).
policy.REASON = {
    INVALID_ARGUMENT = "E_INVALID_ARGUMENT",
    INVALID_VALUE = "E_INVALID_VALUE",
    INVALID_CONTEXT = "E_INVALID_CONTEXT",
    CAPABILITY_UNDECLARED = "E_CAPABILITY_UNDECLARED",
    NOT_FOUND = "E_NOT_FOUND",
    DENIED = "E_DENIED",
    STALE = "E_STALE",
    CLOSED = "E_CLOSED",
    CANCELLED = "E_CANCELLED",
    BUSY = "E_BUSY",
    TOO_LARGE = "E_TOO_LARGE",
    TIMEOUT = "E_TIMEOUT",
    PROFILE_UNAVAILABLE = "E_PROFILE_UNAVAILABLE",
    SECRET_UNAVAILABLE = "E_SECRET_UNAVAILABLE",
    HTTP_FAILURE = "E_HTTP_FAILURE",
    PROVIDER_ERROR = "E_PROVIDER_ERROR",
    MALFORMED_RESPONSE = "E_MALFORMED_RESPONSE",
    TRANSCRIPTION_FAILED = "E_TRANSCRIPTION_FAILED",
    SYNTHESIS_FAILED = "E_SYNTHESIS_FAILED",
    PLAYBACK_FAILED = "E_PLAYBACK_FAILED",
    KEYBOARD_FAILED = "E_KEYBOARD_FAILED",
    TOOL_LOOP_EXHAUSTED = "E_TOOL_LOOP_EXHAUSTED",
    WORK_FAILURE = "E_WORK_FAILURE",
    HOST_FAILURE = "E_HOST_FAILURE",
}

-- Errors that mean "stop immediately; the generation/execution is going away".
policy.STOP_ERRORS = {
    E_CANCELLED = true,
    E_CLOSED = true,
    E_STALE = true,
}

-- ---------------------------------------------------------------------------
-- Small validators.
-- ---------------------------------------------------------------------------
function policy.is_int(value)
    return type(value) == "number" and math.type(value) == "integer"
end

function policy.is_string(value)
    return type(value) == "string"
end

-- A bounded, valid-UTF-8, non-empty string of at most max_bytes.
function policy.bounded_string(value, max_bytes)
    if type(value) ~= "string" or value == "" then
        return false
    end
    if #value > max_bytes then
        return false
    end
    return utf8.len(value) ~= nil
end

-- Trim ASCII/Lua whitespace from both ends.
function policy.trim(text)
    if type(text) ~= "string" then
        return ""
    end
    return (text:gsub("^%s+", ""):gsub("%s+$", ""))
end

function policy.is_nonblank(text)
    return policy.bounded_string(policy.trim(text), policy.MAX_USER_TEXT_BYTES)
end

function policy.is_stop_error(err)
    return type(err) == "table" and policy.STOP_ERRORS[err.error] == true
end

-- A bounded application-failure terminal value for channel callbacks.
function policy.application_failure(code, detail)
    return { error = { code = code, detail = detail } }
end

-- ---------------------------------------------------------------------------
-- Conversation construction.
-- ---------------------------------------------------------------------------
function policy.system_message(prompt)
    return { role = "system", content = prompt }
end

function policy.user_message(text)
    return { role = "user", content = text }
end

function policy.tool_message(call_id, content)
    return { role = "tool", tool_call_id = call_id, content = content }
end

-- Build the assistant message appended to the volatile conversation from a
-- normalized completion. `content` is omitted when blank; `tool_calls` is kept
-- verbatim (arguments remain JSON strings exactly as the provider sent them).
function policy.assistant_message(normalized)
    local message = { role = "assistant" }
    if policy.bounded_string(normalized.content, policy.MAX_ASSISTANT_CONTENT_BYTES) then
        message.content = normalized.content
    end
    if type(normalized.tool_calls) == "table" and #normalized.tool_calls > 0 then
        message.tool_calls = normalized.tool_calls
    end
    return message
end

-- ---------------------------------------------------------------------------
-- Tool definitions (task 15.9: exactly type_text and press_enter).
-- ---------------------------------------------------------------------------
function policy.tool_definitions()
    return {
        {
            type = "function",
            ["function"] = {
                name = policy.TOOL_TYPE_TEXT,
                description = "Type the exact given text into the active input on the controlled device using the configured keyboard.",
                parameters = {
                    type = "object",
                    properties = {
                        text = {
                            type = "string",
                            description = "The exact text to type.",
                        },
                    },
                    required = { "text" },
                    additionalProperties = false,
                },
            },
        },
        {
            type = "function",
            ["function"] = {
                name = policy.TOOL_PRESS_ENTER,
                description = "Press the Enter key on the controlled device using the configured keyboard.",
                parameters = {
                    type = "object",
                    additionalProperties = false,
                },
            },
        },
    }
end

function policy.known_tool(name)
    return name == policy.TOOL_TYPE_TEXT or name == policy.TOOL_PRESS_ENTER
end

-- Validate decoded type_text arguments. Returns the bounded text or
-- (nil, reason). The decoded value is a plain table (JSON object).
function policy.validate_type_text_args(args)
    if type(args) ~= "table" then
        return nil, "arguments must be an object"
    end
    local count = 0
    for key in pairs(args) do
        count = count + 1
        if key ~= "text" then
            return nil, "unknown argument"
        end
    end
    if count ~= 1 then
        return nil, "text is required"
    end
    local text = args.text
    if not policy.bounded_string(text, policy.MAX_TOOL_TEXT_BYTES) then
        return nil, "text must be a non-empty bounded string"
    end
    return text, nil
end

-- Validate decoded press_enter arguments: an empty object only. Returns true or
-- (nil, reason).
function policy.validate_press_enter_args(args)
    if type(args) ~= "table" then
        return nil, "arguments must be an object"
    end
    if next(args) ~= nil then
        return nil, "press_enter takes no arguments"
    end
    return true, nil
end

-- ---------------------------------------------------------------------------
-- Stable effect keys (task 15.8/15.9): derived from durable identity so
-- committed effects memoize across restart and are never ambiguously replayed.
-- ---------------------------------------------------------------------------
function policy.completion_effect_key(turn)
    return "completion:" .. tostring(turn)
end

function policy.tool_effect_key(call_id)
    return "tool:" .. tostring(call_id)
end

-- ---------------------------------------------------------------------------
-- Model-visible tool result content (bounded, non-secret).
-- ---------------------------------------------------------------------------
local function bounded_reason(reason)
    if type(reason) ~= "string" or reason == "" then
        return "unspecified"
    end
    local trimmed = policy.trim(reason)
    if #trimmed > policy.MAX_REASON_BYTES then
        trimmed = trimmed:sub(1, policy.MAX_REASON_BYTES)
    end
    if trimmed == "" then
        return "unspecified"
    end
    return trimmed
end

function policy.tool_result_content(outcome, reason)
    if outcome == policy.OUTCOME_DELIVERED then
        return "delivered"
    end
    if outcome == policy.OUTCOME_INDETERMINATE then
        return "indeterminate: delivery could not be confirmed"
    end
    if outcome == policy.OUTCOME_REJECTED then
        return "rejected: " .. bounded_reason(reason)
    end
    return "failed: " .. bounded_reason(reason)
end

-- ---------------------------------------------------------------------------
-- Tool-call structural extraction and validation.
--
-- A provider tool call is {id, type="function", ["function"]={name, arguments}}
-- where `arguments` is a JSON string. The caller decodes `arguments` and passes
-- the decoded table to the per-tool validators above.
-- ---------------------------------------------------------------------------

-- Extract the list of tool calls from a normalized assistant message, or nil.
function policy.assistant_tool_calls(normalized)
    local calls = normalized and normalized.tool_calls
    if type(calls) ~= "table" or #calls == 0 then
        return nil
    end
    return calls
end

-- Structural validation of one raw tool call (before argument decoding).
-- Returns a descriptor {id, name, arguments} or (nil, reason).
function policy.parse_tool_call(call)
    if type(call) ~= "table" then
        return nil, "malformed tool call"
    end
    local id = call.id
    if not policy.bounded_string(id, policy.MAX_CALL_ID_BYTES) then
        return nil, "missing tool call id"
    end
    if call.type ~= "function" then
        return nil, "unsupported tool call type"
    end
    local fn = call["function"]
    if type(fn) ~= "table" then
        return nil, "malformed tool call function"
    end
    local name = fn.name
    if not policy.bounded_string(name, policy.MAX_CALL_ID_BYTES) then
        return nil, "missing tool name"
    end
    if not policy.known_tool(name) then
        return nil, "unknown tool"
    end
    local arguments = fn.arguments
    if arguments == nil then
        arguments = ""
    end
    if type(arguments) ~= "string" then
        return nil, "tool arguments must be a JSON string"
    end
    return { id = id, name = name, arguments = arguments }, nil
end

-- ---------------------------------------------------------------------------
-- Completion response normalization.
--
-- The vendored client returns the DECODED Chat Completion body (a table) for a
-- transport success, or a string when the body was not valid JSON. A non-2xx
-- status is still a transport success; the caller decides how to treat it.
-- Normalization strips the JSON null sentinel (callers pass `null`) so the
-- result is durable-safe (work effect results reject the null sentinel).
-- ---------------------------------------------------------------------------

-- Normalize one raw tool call table from a provider message into a plain,
-- durable-safe {id, type, ["function"]={name, arguments}} or nil.
local function normalize_tool_call(call, null)
    if type(call) ~= "table" then
        return nil
    end
    local id = call.id
    if type(id) ~= "string" or id == "" or id == null then
        return nil
    end
    local fn = call["function"]
    if type(fn) ~= "table" then
        return nil
    end
    local name = fn.name
    if type(name) ~= "string" or name == "" then
        return nil
    end
    local arguments = fn.arguments
    if arguments == null or arguments == nil then
        arguments = ""
    end
    if type(arguments) ~= "string" then
        return nil
    end
    local ctype = call.type
    if ctype == nil or ctype == null then
        ctype = "function"
    end
    if type(ctype) ~= "string" then
        return nil
    end
    return {
        id = id,
        type = ctype,
        ["function"] = { name = name, arguments = arguments },
    }
end

-- Normalize a decoded Chat Completion response into a durable-safe shape:
--   { kind="completion", status=<int>, message={content?, tool_calls?} }
-- or (nil, reason) when the body is structurally unusable. `null` is the JSON
-- null sentinel used to recognize provider nulls (cjson.null).
function policy.normalize_completion(status, body, null)
    if not policy.is_int(status) then
        return nil, "invalid status"
    end
    if type(body) ~= "table" then
        return nil, "response is not a JSON object"
    end
    local choices = body.choices
    if type(choices) ~= "table" or choices[1] == nil then
        return nil, "response has no choices"
    end
    local first = choices[1]
    if type(first) ~= "table" then
        return nil, "malformed choice"
    end
    local message = first.message
    if type(message) ~= "table" or message.role ~= "assistant" then
        return nil, "choice has no assistant message"
    end

    local normalized = { kind = "completion", status = status, message = { role = "assistant" } }

    local content = message.content
    if type(content) == "string" and content ~= "" and content ~= null
        and policy.bounded_string(content, policy.MAX_ASSISTANT_CONTENT_BYTES) then
        normalized.message.content = content
    end

    local raw_calls = message.tool_calls
    if type(raw_calls) == "table" and #raw_calls > 0 then
        local calls = {}
        for _, raw in ipairs(raw_calls) do
            local call = normalize_tool_call(raw, null)
            if call == nil then
                return nil, "malformed tool call in response"
            end
            calls[#calls + 1] = call
        end
        normalized.message.tool_calls = calls
    end

    if normalized.message.content == nil and normalized.message.tool_calls == nil then
        return nil, "assistant message has neither content nor tool calls"
    end
    return normalized, nil
end

-- The final nonblank assistant text of a normalized completion, if it is a
-- terminal (no tool calls) response; otherwise nil.
function policy.final_text(normalized)
    if type(normalized) ~= "table" or type(normalized.message) ~= "table" then
        return nil
    end
    if normalized.message.tool_calls ~= nil then
        return nil
    end
    local content = normalized.message.content
    if policy.bounded_string(content, policy.MAX_ASSISTANT_CONTENT_BYTES)
        and policy.is_nonblank(content) then
        return policy.trim(content)
    end
    return nil
end

-- Classify a thrown error from the vendored client (pcall message) into a
-- bounded, content-free reason code.
function policy.classify_throw(message)
    if type(message) == "string" then
        local code = message:match("(E_[A-Z_]+)")
        if code and policy.REASON[code] ~= nil then
            return code
        end
        if code then
            return code
        end
    end
    return policy.REASON.HTTP_FAILURE
end

return policy
