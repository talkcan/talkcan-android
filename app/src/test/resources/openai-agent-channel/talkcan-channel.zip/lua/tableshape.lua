return require("tableshape.init")
