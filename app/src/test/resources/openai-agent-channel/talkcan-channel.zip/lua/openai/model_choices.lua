-- One-shot dynamic-choice resolver: OpenAI-compatible model discovery.
--
-- Declared in the manifest as choiceResolvers[{id="models", module=
-- "openai.model_choices", capabilities=[network.http, profiles.read,
-- secrets.read]}]. The host loads ONLY this module in a fresh restricted
-- resolver state, calls `resolve(request)` exactly once, validates the returned
-- choices, and closes the state. No channel runtime, durable work item, audio
-- route, or keyboard effect is created here.
--
-- Authority is narrow: the resolver may read exactly its one selected profile
-- (talkcan.profiles), resolve that profile's API-key reference
-- (talkcan.secrets), and issue HTTPS through the vendored client
-- (talkcan.http via the package socket.http adapter). It resolves the
-- profile's `/models` operation and returns bounded unique model IDs.
--
-- Any missing/unauthorized/unreachable/malformed/timed-out/stale result becomes
-- a typed unavailable error; no fallback model is ever chosen and no host/Kotlin
-- discovery path is used. Logs are bounded and content-free (no base URL, key,
-- or model payload).
local secrets = require("talkcan.secrets")
local log = require("talkcan.log")
local policy = require("policy")
local profile = require("profile")
local client = require("client")

local RESOLVER_ID = "models"

local function bounded_log(level, payload)
    local fn = log[level]
    if type(fn) == "function" then
        fn(payload)
    end
end

local function fail(code)
    return nil, { error = code }
end

local function resolve(request)
    if type(request) ~= "table" or request.schema_version ~= policy.SCHEMA_VERSION then
        return fail(policy.REASON.INVALID_ARGUMENT)
    end
    if request.resolver ~= RESOLVER_ID then
        return fail(policy.REASON.INVALID_ARGUMENT)
    end

    -- The selected profile id arrives either as `request.profile` or as the
    -- scalar value of the declared dependency field.
    local profile_id
    if type(request.profile) == "string" then
        profile_id = request.profile
    elseif type(request.dependency) == "table" and type(request.dependency.value) == "string" then
        profile_id = request.dependency.value
    end
    if not policy.bounded_string(profile_id, 256) then
        return fail(policy.REASON.INVALID_ARGUMENT)
    end

    bounded_log("debug", { message = "openai_models_resolve_begin" })

    local prof, perr = profile.resolve(profile_id)
    if prof == nil then
        bounded_log("warn", {
            message = "openai_models_profile_unavailable",
            error = (perr and perr.error) or policy.REASON.PROFILE_UNAVAILABLE,
        })
        return fail((perr and perr.error) or policy.REASON.PROFILE_UNAVAILABLE)
    end

    local api_key, serr = secrets.read(prof.api_key_ref)
    if api_key == nil then
        bounded_log("warn", {
            message = "openai_models_secret_unavailable",
            error = (serr and serr.error) or policy.REASON.SECRET_UNAVAILABLE,
        })
        return fail((serr and serr.error) or policy.REASON.SECRET_UNAVAILABLE)
    end

    local instance, cerr = client.new(prof.base_url, api_key)
    if instance == nil then
        return fail((cerr and cerr.error) or policy.REASON.INVALID_VALUE)
    end

    local ok, status, body = pcall(client.models, instance)
    if not ok then
        local code = policy.classify_throw(status)
        bounded_log("warn", { message = "openai_models_transport_failed", error = code })
        return fail(code)
    end
    if status ~= 200 then
        bounded_log("warn", {
            message = "openai_models_provider_error",
            status_class = (status // 100) * 100,
        })
        return fail(policy.REASON.PROVIDER_ERROR)
    end
    if type(body) ~= "table" or type(body.data) ~= "table" then
        bounded_log("warn", { message = "openai_models_malformed_response" })
        return fail(policy.REASON.MALFORMED_RESPONSE)
    end

    local choices = {}
    local seen = {}
    for _, entry in ipairs(body.data) do
        if type(entry) == "table" then
            local id = entry.id
            if policy.bounded_string(id, policy.MAX_MODEL_ID_BYTES) and not seen[id] then
                seen[id] = true
                choices[#choices + 1] = { value = id, label = id }
            end
        end
    end
    if #choices == 0 then
        bounded_log("warn", { message = "openai_models_empty" })
        return fail(policy.REASON.PROVIDER_ERROR)
    end

    bounded_log("info", { message = "openai_models_resolved", count = #choices })
    return { choices = choices }, nil
end

return { resolve = resolve }
