-- Package-local LuaSocket `socket.http` compatibility adapter.
--
-- lua-openai performs every request through `require(self.config.http_provider)`
-- which defaults to `socket.http` outside nginx. The vendored client calls the
-- LuaSocket "simple request with a table" interface:
--
--     local _, status, headers = assert(http.request({
--         url = ..., method = ..., headers = ..., source = ..., sink = ...,
--     }))
--
-- and collects the response body through the LTN12 sink it supplied. This
-- adapter drains the LTN12 request source into a complete bounded UTF-8 body,
-- issues ONE complete request through the host-injected, capability-gated
-- `subspace.http`, feeds the complete response body into the supplied sink, and
-- returns the LuaSocket-compatible `1, status, headers` / `nil, error` pair.
--
-- It owns no TLS, DNS, sockets, redirects, or streaming; all of that is
-- host-owned. Non-2xx statuses are transport successes (the client interprets
-- them). There is no native LuaSocket and no host OpenAI fallback.
local http = require("subspace.http")

local M = {}

-- Headers the generic HTTPS transport owns and derives itself from the
-- absolute URL and body. The vendored client sets Host and Content-Length
-- (LuaSocket convention); forwarding them would conflict with host policy, so
-- the adapter drops them case-insensitively. Hop-by-hop headers are likewise
-- meaningless over a complete bounded request/response and are dropped.
-- Application headers (Authorization, Content-Type, Accept, ...) are forwarded
-- verbatim.
local OWNED_OR_HOP_BY_HOP = {
    ["host"] = true,
    ["content-length"] = true,
    ["connection"] = true,
    ["keep-alive"] = true,
    ["proxy-connection"] = true,
    ["transfer-encoding"] = true,
    ["te"] = true,
    ["trailer"] = true,
    ["upgrade"] = true,
}

-- Drain an LTN12 source completely into a string. A nil source yields an empty
-- body (e.g. GET). A source error aborts the whole request before any effect.
local function drain_source(source)
    if source == nil then
        return "", nil
    end
    if type(source) ~= "function" then
        return nil, "invalid source"
    end
    local parts = {}
    while true do
        local chunk, err = source()
        if chunk == nil then
            if err ~= nil then
                return nil, err
            end
            break
        end
        parts[#parts + 1] = chunk
    end
    return table.concat(parts), nil
end

local function forward_headers(headers)
    local out = {}
    if type(headers) == "table" then
        for name, value in pairs(headers) do
            if type(name) == "string" and type(value) ~= "nil"
                and not OWNED_OR_HOP_BY_HOP[name:lower()] then
                out[name] = tostring(value)
            end
        end
    end
    return out
end

local function error_code(err, fallback)
    if type(err) == "table" and type(err.error) == "string" then
        return err.error
    end
    if type(err) == "string" and err ~= "" then
        return err
    end
    return fallback
end

-- The single LuaSocket-compatible entry point used by the vendored client.
function M.request(params)
    if type(params) ~= "table" then
        return nil, "request table required"
    end
    local url = params.url
    if type(url) ~= "string" or url == "" then
        return nil, "invalid url"
    end
    local method = params.method or "GET"

    local body, drain_err = drain_source(params.source)
    if body == nil then
        return nil, drain_err or "source error"
    end

    local request = {
        method = method,
        url = url,
        headers = forward_headers(params.headers),
    }
    if body ~= "" then
        request.body = body
    end
    if type(params.timeout_ms) == "number" and math.type(params.timeout_ms) == "integer"
        and params.timeout_ms > 0 then
        request.timeout_ms = params.timeout_ms
    end

    local response, err = http.request(request)
    if response == nil then
        return nil, error_code(err, "E_HTTP_FAILURE")
    end
    if type(response) ~= "table" or type(response.status) ~= "number" then
        return nil, "E_INVALID_VALUE"
    end

    local sink = params.sink
    if type(sink) == "function" then
        local ok, sink_err = sink(type(response.body) == "string" and response.body or "")
        if not ok then
            return nil, error_code(sink_err, "sink error")
        end
        sink(nil)
    end

    return 1, response.status, type(response.headers) == "table" and response.headers or {}
end

return M
