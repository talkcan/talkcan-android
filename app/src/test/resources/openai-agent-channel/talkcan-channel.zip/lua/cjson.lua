-- Package-local CJSON compatibility adapter (NOT a host compatibility promise).
--
-- lua-openai expects the lua-cjson ABI subset {encode, decode, null}. This
-- module delegates every operation to the host-injected, capability-free,
-- bounded `subspace.json` codec (Rust/serde_json) and exposes only the
-- upstream behavior the vendored client requires:
--
--   * `null`    -- the exact state-local JSON null sentinel (subspace.json.null)
--   * `encode`  -- value -> JSON text, raising a Lua error on failure
--   * `decode`  -- JSON text -> value, raising a Lua error on failure
--
-- The host does not reserve `cjson`; this module is resolved from the package
-- source map like any other module. Native lua-cjson remains prohibited. The
-- throwing semantics match lua-cjson (the client pcalls decode and calls
-- encode directly), so a failed encode/decode surfaces as a Lua error that the
-- package policy normalizes into a bounded application failure.
local json = require("subspace.json")

local cjson = {}

-- The exact state-local null sentinel. lua-openai compares decoded fields
-- against `cjson.null` (e.g. `types.literal(cjson.null)`), so this MUST be the
-- same sentinel subspace.json.decode places for JSON null.
cjson.null = json.null

local function fail(operation, err)
    local code = "E_INVALID_VALUE"
    if type(err) == "table" and type(err.error) == "string" then
        code = err.error
    end
    -- Content-free message: no value, key, or document bytes are formatted.
    error("cjson." .. operation .. ": " .. code, 3)
end

function cjson.encode(value)
    local text, err = json.encode(value)
    if text == nil then
        fail("encode", err)
    end
    return text
end

function cjson.decode(text)
    if type(text) ~= "string" then
        error("cjson.decode: expected a string argument", 2)
    end
    local value, err = json.decode(text)
    if err ~= nil then
        fail("decode", err)
    end
    return value
end

return cjson
