return require("openai.init")
