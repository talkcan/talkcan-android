-- Selected package-profile resolution for the OpenAI Agent package.
--
-- Centralizes the single documented detached-profile shape so the resolver and
-- the worker read it identically and a future host-contract correction touches
-- exactly one place.
--
-- Documented detached shape (spec lua-profile-types; the host Kotlin record
-- splits `scalarPayload` (NON-secret scalars only) from `secretReferences`):
--
--     {
--       id   = "<stable profile id>",
--       type = "<local type id>",           -- "openai_compatible"
--       name = "<display name>",
--       values     = { base_url = "https://..." },   -- non-secret scalars only
--       secrets = { api_key = <opaque SecretReference> },  -- secret refs
--     }
--
-- `values` never contains plaintext or secret references; secret fields are
-- exposed only as opaque state-local handles resolved through talkcan.secrets.
local profiles = require("talkcan.profiles")
local policy = require("policy")

local profile = {}

local MAX_PROFILE_ID_BYTES = 256

-- Resolve the selected profile and return {id, base_url, api_key_ref} or
-- (nil, error_table). Every failure is a bounded, content-free code.
function profile.resolve(profile_id)
    if not policy.bounded_string(profile_id, MAX_PROFILE_ID_BYTES) then
        return nil, { error = policy.REASON.INVALID_ARGUMENT }
    end
    local value, err = profiles.get(profile_id)
    if value == nil then
        if type(err) == "table" and type(err.error) == "string" then
            return nil, err
        end
        return nil, { error = policy.REASON.PROFILE_UNAVAILABLE }
    end
    if type(value) ~= "table" then
        return nil, { error = policy.REASON.PROFILE_UNAVAILABLE }
    end

    local values = value.values
    if type(values) ~= "table" then
        return nil, { error = policy.REASON.PROFILE_UNAVAILABLE }
    end
    local base_url = values.base_url
    if not policy.bounded_string(base_url, policy.MAX_BASE_URL_BYTES) then
        return nil, { error = policy.REASON.PROFILE_UNAVAILABLE }
    end

    local secrets = value.secrets
    if type(secrets) ~= "table" then
        return nil, { error = policy.REASON.PROFILE_UNAVAILABLE }
    end
    local api_key_ref = secrets.api_key
    if api_key_ref == nil then
        return nil, { error = policy.REASON.SECRET_UNAVAILABLE }
    end

    return {
        id = (type(value.id) == "string" and value.id ~= "") and value.id or profile_id,
        base_url = base_url,
        api_key_ref = api_key_ref,
    }, nil
end

return profile
