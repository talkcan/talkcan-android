-- OpenAI Agent channel package entry module.
--
-- This is the package's single entry point (manifest entryModule = "plugin").
-- It exports exactly the three channel callbacks the host invokes:
--
--   startup(configuration)   -- open the turns queue, spawn the worker
--   handle_readiness(context)-- validate all generic dependencies
--   handle_input(event)      -- transcribe PTT audio, submit durable turn
--
-- All provider policy (model discovery, completion loop, tool dispatch,
-- synthesis, playback) lives in the agent and policy modules. This module only
-- wires host callbacks to the durable worker and enforces input admission
-- semantics: transcription and durable queue admission precede callback
-- success; the callback never waits for remote completion.
local work = require("subspace.work")
local transcription = require("subspace.transcription")
local runtime = require("subspace.runtime")
local log = require("subspace.log")

local policy = require("policy")
local agent = require("agent")

local QUEUE_ID = "turns"

-- Module-local runtime state, set once during startup.
local state = {
    queue = nil,
    config = nil,
    ready = false,
}

local function bounded_log(level, payload)
    local fn = log[level]
    if type(fn) == "function" then
        fn(payload)
    end
end

-- ---------------------------------------------------------------------------
-- Configuration validation.
-- ---------------------------------------------------------------------------
local function validate_configuration(configuration)
    if type(configuration) ~= "table" then
        return nil, "configuration must be a table"
    end
    if configuration.schema_version ~= policy.SCHEMA_VERSION then
        return nil, "unsupported configuration schema version"
    end
    local values = configuration.values
    if type(values) ~= "table" then
        return nil, "configuration values must be a table"
    end

    -- Profile id: required nonblank string.
    if not policy.bounded_string(values.profile_id, 256) then
        return nil, "profile_id is required"
    end
    -- Model: required nonblank string.
    if not policy.bounded_string(values.model, policy.MAX_MODEL_ID_BYTES) then
        return nil, "model is required"
    end
    -- System prompt: required nonblank bounded string (may contain newlines).
    if not policy.bounded_string(values.system_prompt, policy.MAX_SYSTEM_PROMPT_BYTES) then
        return nil, "system_prompt is required"
    end

    local keyboard_enabled = values.keyboard_enabled == true
    local host_profile = values.host_profile
    if keyboard_enabled then
        if not policy.bounded_string(host_profile, 256) then
            return nil, "host_profile is required when keyboard is enabled"
        end
    end

    return {
        profile_id = values.profile_id,
        model = values.model,
        system_prompt = values.system_prompt,
        keyboard_enabled = keyboard_enabled,
        host_profile = keyboard_enabled and host_profile or nil,
    }, nil
end

-- ---------------------------------------------------------------------------
-- startup: open the turns queue and spawn the worker.
-- ---------------------------------------------------------------------------
local function startup(configuration)
    local config, verr = validate_configuration(configuration)
    if config == nil then
        bounded_log("error", { message = "openai_startup_invalid_config", detail = verr })
        return policy.application_failure(policy.REASON.INVALID_ARGUMENT, verr or "invalid configuration")
    end
    state.config = config

    local queue, qerr = work.open(QUEUE_ID)
    if queue == nil then
        local code = (qerr and qerr.error) or policy.REASON.WORK_FAILURE
        bounded_log("error", { message = "openai_startup_queue_open_failed", error = code })
        return policy.application_failure(code, "cannot open turns queue")
    end
    state.queue = queue

    -- Spawn the worker. It begins only after successful Ready publication.
    local ok, serr = runtime.spawn(function()
        agent.run_worker(queue, config)
    end)
    if not ok then
        local code = (serr and serr.error) or policy.REASON.HOST_FAILURE
        bounded_log("error", { message = "openai_startup_spawn_failed", error = code })
        return policy.application_failure(code, "cannot admit worker")
    end

    state.ready = true
    bounded_log("info", {
        message = "openai_startup_complete",
        keyboard_enabled = config.keyboard_enabled,
    })
    return nil
end

-- ---------------------------------------------------------------------------
-- handle_readiness: validate all generic dependencies without remote calls.
-- ---------------------------------------------------------------------------
local REQUIRED_CAPABILITIES = {
    "audio.transcription",
    "audio.synthesis",
    "audio.playback",
    "network.http",
    "secrets.read",
    "work.queue",
}

local function handle_readiness(context)
    if not state.ready or state.config == nil or state.queue == nil then
        return { ready = false, status = "not started" }
    end
    if type(context) ~= "table" or type(context.capabilities) ~= "table" then
        return { ready = false, status = "no capability context" }
    end

    for _, cap in ipairs(REQUIRED_CAPABILITIES) do
        if context.capabilities[cap] ~= "available" then
            return { ready = false, status = "missing " .. cap }
        end
    end

    -- Keyboard dependencies: only required when keyboard tools are enabled.
    if state.config.keyboard_enabled then
        if context.capabilities["keyboard.output"] ~= "available" then
            return { ready = false, status = "missing keyboard.output" }
        end
        if not policy.bounded_string(state.config.host_profile, 256) then
            return { ready = false, status = "keyboard profile not configured" }
        end
    end

    return { ready = true, status = "ready" }
end

-- ---------------------------------------------------------------------------
-- handle_input: transcribe PTT audio, submit durable turn.
--
-- Transcription and durable queue admission precede callback success. The
-- callback never waits for Chat Completion, tool execution, synthesis, or
-- playback. It does not retain the Recording, audio route, PTT callback,
-- secret, client, or queue Job.
-- ---------------------------------------------------------------------------
local function handle_input(event)
    if not state.ready or state.queue == nil then
        return policy.application_failure(policy.REASON.INVALID_CONTEXT, "channel not started")
    end
    if type(event) ~= "table" then
        return policy.application_failure(policy.REASON.INVALID_ARGUMENT, "invalid input event")
    end
    if event.event ~= "capture" then
        return policy.application_failure(policy.REASON.INVALID_ARGUMENT, "unsupported event type")
    end
    if type(event.audio) ~= "userdata" then
        return policy.application_failure(policy.REASON.INVALID_ARGUMENT, "missing recording")
    end

    -- Transcribe the committed Recording.
    local result, terr = transcription.transcribe(event.audio)
    if result == nil then
        local code = (terr and terr.error) or policy.REASON.TRANSCRIPTION_FAILED
        bounded_log("warn", { message = "openai_input_transcription_failed", error = code })
        return policy.application_failure(code, "transcription failed")
    end
    if type(result) ~= "table" or type(result.text) ~= "string" then
        return policy.application_failure(policy.REASON.TRANSCRIPTION_FAILED, "invalid transcription result")
    end

    local text = policy.trim(result.text)
    if not policy.is_nonblank(text) then
        bounded_log("info", { message = "openai_input_blank_transcript" })
        return policy.application_failure(policy.REASON.INVALID_VALUE, "blank transcript")
    end
    if #text > policy.MAX_USER_TEXT_BYTES then
        return policy.application_failure(policy.REASON.TOO_LARGE, "transcript too long")
    end

    -- Submit the durable turn. Success means the payload and FIFO position
    -- survive process death; the callback returns without waiting for
    -- processing.
    local submit_result, serr = state.queue:submit({
        schema_version = policy.SCHEMA_VERSION,
        user_text = text,
    })
    if submit_result == nil then
        local code = (serr and serr.error) or policy.REASON.WORK_FAILURE
        bounded_log("warn", { message = "openai_input_submit_failed", error = code })
        return policy.application_failure(code, "queue admission failed")
    end

    bounded_log("info", { message = "openai_input_admitted", bytes = #text })
    return { ok = true }
end

return {
    startup = startup,
    handle_readiness = handle_readiness,
    handle_input = handle_input,
}
