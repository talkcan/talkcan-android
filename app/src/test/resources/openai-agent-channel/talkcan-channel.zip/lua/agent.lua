-- Durable turn worker for the OpenAI Agent channel package.
--
-- One managed worker serializes turns for each instance. It blocks
-- cooperatively on Queue:receive, processes at most one Job at a time in FIFO
-- order, and allows later turns to remain durably queued.
--
-- Each generation owns one volatile conversation beginning with the configured
-- system prompt. Completed sequential Jobs in one generation share that
-- conversation. Process restart, SOS, configuration replacement, package
-- replacement/rollback/removal, or runtime closure discards it.
--
-- Chat Completion calls execute through stable Job:effect keys so committed
-- normalized responses are memoized and ambiguous submissions are never
-- replayed. Keyboard tool calls likewise use stable call-derived effect keys.
-- Synthesis and playback are host operations under the Job owner; successful
-- playback-queue admission occurs before Job:complete.
local cjson = require("cjson")
local policy = require("policy")
local client = require("client")
local profile_mod = require("profile")

local synthesis = require("talkcan.synthesis")
local playback = require("talkcan.playback")
local keyboard_output = require("talkcan.keyboard_output")
local secrets = require("talkcan.secrets")
local log = require("talkcan.log")

local agent = {}

local function bounded_log(level, payload)
    local fn = log[level]
    if type(fn) == "function" then
        fn(payload)
    end
end

-- ---------------------------------------------------------------------------
-- Completion effect: one bounded non-streaming Chat Completion call.
-- ---------------------------------------------------------------------------
local function do_completion(job, turn, instance, messages, params)
    local key = policy.completion_effect_key(turn)
    local normalized, err = job:effect(key, function()
        local ok, status, response = pcall(client.chat, instance, messages, params)
        if not ok then
            return nil, { error = policy.classify_throw(status) }
        end
        if type(status) ~= "number" or status ~= 200 then
            local failure = { error = policy.REASON.PROVIDER_ERROR }
            if type(status) == "number" then
                failure.status_class = tostring(math.floor(status / 100)) .. "xx"
            end
            return nil, failure
        end
        local norm = policy.normalize_completion(status, response, cjson.null)
        if norm == nil then
            return nil, { error = policy.REASON.MALFORMED_RESPONSE }
        end
        return norm, nil
    end)
    return normalized, err
end

-- ---------------------------------------------------------------------------
-- Keyboard tool effect: one semantic keyboard-output operation.
-- ---------------------------------------------------------------------------
local function execute_tool(job, parsed, validated_arg, host_profile)
    local key = policy.tool_effect_key(parsed.id)
    local result, err = job:effect(key, function()
        local outcome, reason
        if parsed.name == policy.TOOL_TYPE_TEXT then
            local ok, kerr = keyboard_output.send_text({
                text = validated_arg,
                profile = host_profile,
            })
            if ok then
                outcome = policy.OUTCOME_DELIVERED
            else
                outcome = policy.OUTCOME_FAILED
                reason = (kerr and kerr.error) or "keyboard failure"
            end
        elseif parsed.name == policy.TOOL_PRESS_ENTER then
            local ok, kerr = keyboard_output.send_key({
                key = policy.ENTER_KEY,
                profile = host_profile,
            })
            if ok then
                outcome = policy.OUTCOME_DELIVERED
            else
                outcome = policy.OUTCOME_FAILED
                reason = (kerr and kerr.error) or "keyboard failure"
            end
        else
            outcome = policy.OUTCOME_REJECTED
            reason = "unknown tool"
        end
        return { outcome = outcome, reason = reason }, nil
    end)
    return result, err
end

-- ---------------------------------------------------------------------------
-- Synthesis and delayed-playback admission.
-- ---------------------------------------------------------------------------
local function synthesize_and_playback(text)
    local audio, serr = synthesis.synthesize({
        text = text,
        language = "en",
        voice = "default",
    })
    if audio == nil then
        local code = (serr and serr.error) or policy.REASON.SYNTHESIS_FAILED
        bounded_log("warn", { message = "openai_synthesis_failed", error = code })
        return nil, { error = code }
    end
    local result, perr = playback.schedule(audio, {})
    if result == nil then
        local code = (perr and perr.error) or policy.REASON.PLAYBACK_FAILED
        bounded_log("warn", { message = "openai_playback_failed", error = code })
        return nil, { error = code }
    end
    return true, nil
end

-- ---------------------------------------------------------------------------
-- Decode tool-call arguments safely.
-- ---------------------------------------------------------------------------
local function decode_arguments(arguments_string)
    if arguments_string == nil or arguments_string == "" then
        return {}, nil
    end
    local ok, decoded = pcall(cjson.decode, arguments_string)
    if not ok then
        return nil, "malformed JSON arguments"
    end
    return decoded, nil
end

-- ---------------------------------------------------------------------------
-- Detached deep copy of a conversation value (plain strings/tables only;
-- normalized messages carry no JSON null sentinel).
-- ---------------------------------------------------------------------------
local function deep_copy_value(value)
    if type(value) ~= "table" then return value end
    local copy = {}
    for k, v in pairs(value) do copy[k] = deep_copy_value(v) end
    return copy
end

-- ---------------------------------------------------------------------------
-- Process one Job: the bounded completion/tool loop.
--
-- `conversation` is the live volatile conversation of the worker generation
-- (system-only on a fresh worker; callers MAY omit it to start fresh). The
-- Job processes a DETACHED candidate copy with this turn's user message
-- appended and returns it on successful terminal completion; the worker
-- publishes it back. Failed Jobs return nothing, so they never mutate the
-- prior conversation.
-- ---------------------------------------------------------------------------
function agent.process_job(job, config, conversation)
    local payload = job:payload()
    if type(payload) ~= "table" then
        bounded_log("warn", { message = "openai_payload_invalid", error = policy.REASON.INVALID_VALUE })
        job:fail({ error = policy.REASON.INVALID_VALUE })
        return
    end
    if payload.schema_version ~= policy.SCHEMA_VERSION then
        bounded_log("warn", { message = "openai_payload_invalid", error = policy.REASON.INVALID_VALUE })
        job:fail({ error = policy.REASON.INVALID_VALUE })
        return
    end
    local user_text = payload.user_text
    if not policy.bounded_string(user_text, policy.MAX_USER_TEXT_BYTES) then
        bounded_log("warn", { message = "openai_payload_invalid", error = policy.REASON.INVALID_VALUE })
        job:fail({ error = policy.REASON.INVALID_VALUE })
        return
    end

    -- Resolve profile and secret for this generation.
    local prof, perr = profile_mod.resolve(config.profile_id)
    if prof == nil then
        local code = (perr and perr.error) or policy.REASON.PROFILE_UNAVAILABLE
        bounded_log("warn", { message = "openai_profile_unavailable", error = code })
        job:fail({ error = code })
        return
    end
    local api_key, serr = secrets.read(prof.api_key_ref)
    if api_key == nil then
        local code = (serr and serr.error) or policy.REASON.SECRET_UNAVAILABLE
        bounded_log("warn", { message = "openai_secret_unavailable", error = code })
        job:fail({ error = code })
        return
    end
    local instance, cerr = client.new(prof.base_url, api_key)
    if instance == nil then
        local code = (cerr and cerr.error) or policy.REASON.INVALID_VALUE
        bounded_log("warn", { message = "openai_client_invalid", error = code })
        job:fail({ error = code })
        return
    end

    -- Detached candidate conversation for this Job: a copy of the live
    -- generation conversation (system-only when none is supplied) with this
    -- turn's user message appended.
    local messages
    if type(conversation) == "table" then
        messages = deep_copy_value(conversation)
    else
        messages = { policy.system_message(config.system_prompt) }
    end
    messages[#messages + 1] = policy.user_message(user_text)

    -- Request parameters: non-streaming, parallel_tool_calls=false.
    local params = {
        model = config.model,
        parallel_tool_calls = false,
    }
    if config.keyboard_enabled then
        params.tools = policy.tool_definitions()
    end

    local total_tool_calls = 0
    local seen_call_ids = {}

    for turn = 1, policy.MAX_MODEL_TURNS do
        local normalized, effect_err = do_completion(job, turn, instance, messages, params)
        if normalized == nil then
            local diagnostic = {
                message = "openai_completion_failed",
                error = (effect_err and effect_err.error) or policy.REASON.WORK_FAILURE,
            }
            if effect_err and effect_err.status_class then
                diagnostic.status_class = effect_err.status_class
            end
            bounded_log("warn", diagnostic)
            local code = (effect_err and effect_err.error) or policy.REASON.WORK_FAILURE
            if policy.STOP_ERRORS[code] then
                job:fail(effect_err)
            else
                job:fail({ error = code })
            end
            return
        end

        -- Append the assistant message to the volatile conversation.
        messages[#messages + 1] = policy.assistant_message(normalized.message)

        -- Terminal: final assistant text with no tool calls.
        local final = policy.final_text(normalized)
        if final then
            local ok, sp_err = synthesize_and_playback(final)
            if ok == nil then
                job:fail(sp_err or { error = policy.REASON.SYNTHESIS_FAILED })
                return
            end
            bounded_log("info", {
                message = "openai_turn_completed",
                turns = turn,
                tool_calls = total_tool_calls,
            })
            job:complete({ status = "completed" })
            return messages
        end

        -- Tool calls.
        local calls = policy.assistant_tool_calls(normalized.message)
        if calls == nil then
            -- No content and no tool calls: structurally invalid.
            bounded_log("warn", { message = "openai_malformed_final", error = policy.REASON.MALFORMED_RESPONSE })
            job:fail({ error = policy.REASON.MALFORMED_RESPONSE })
            return
        end

        -- Parallel tool calls are not supported (parallel_tool_calls=false).
        if #calls > 1 then
            for _, raw_call in ipairs(calls) do
                local cid = (type(raw_call) == "table" and type(raw_call.id) == "string")
                    and raw_call.id or "unknown"
                messages[#messages + 1] = policy.tool_message(
                    cid,
                    policy.tool_result_content(policy.OUTCOME_REJECTED, "parallel tool calls not supported")
                )
            end
            -- Continue to next turn so the model sees the rejections.
        else
            -- Exactly one tool call.
            local raw_call = calls[1]
            local parsed, parse_err = policy.parse_tool_call(raw_call)

            if parsed == nil then
                -- Structurally invalid call: reject without keyboard effect.
                local cid = (type(raw_call) == "table" and type(raw_call.id) == "string")
                    and raw_call.id or "unknown"
                messages[#messages + 1] = policy.tool_message(
                    cid,
                    policy.tool_result_content(policy.OUTCOME_REJECTED, parse_err)
                )
            elseif seen_call_ids[parsed.id] then
                -- Duplicate call id: reject without keyboard effect.
                messages[#messages + 1] = policy.tool_message(
                    parsed.id,
                    policy.tool_result_content(policy.OUTCOME_REJECTED, "duplicate call id")
                )
            elseif not config.keyboard_enabled then
                -- Keyboard disabled: reject without keyboard effect.
                messages[#messages + 1] = policy.tool_message(
                    parsed.id,
                    policy.tool_result_content(policy.OUTCOME_REJECTED, "keyboard disabled")
                )
            else
                seen_call_ids[parsed.id] = true
                total_tool_calls = total_tool_calls + 1
                if total_tool_calls > policy.MAX_TOOL_CALLS_TOTAL then
                    bounded_log("warn", { message = "openai_tool_budget_exhausted", error = policy.REASON.TOOL_LOOP_EXHAUSTED })
                    job:fail({ error = policy.REASON.TOOL_LOOP_EXHAUSTED })
                    return
                end

                -- Decode and validate arguments before any effect.
                local args, decode_err = decode_arguments(parsed.arguments)
                local validated_arg, val_err
                if args == nil then
                    val_err = decode_err
                elseif parsed.name == policy.TOOL_TYPE_TEXT then
                    validated_arg, val_err = policy.validate_type_text_args(args)
                elseif parsed.name == policy.TOOL_PRESS_ENTER then
                    validated_arg, val_err = policy.validate_press_enter_args(args)
                else
                    val_err = "unknown tool"
                end

                if validated_arg == nil and parsed.name == policy.TOOL_PRESS_ENTER and val_err == nil then
                    -- press_enter returns true, not a string arg.
                    validated_arg = true
                end

                if validated_arg == nil then
                    -- Invalid arguments: reject without keyboard effect.
                    messages[#messages + 1] = policy.tool_message(
                        parsed.id,
                        policy.tool_result_content(policy.OUTCOME_REJECTED, val_err)
                    )
                else
                    -- Execute the keyboard effect durably.
                    local result, tool_err = execute_tool(job, parsed, validated_arg, config.host_profile)
                    if result == nil then
                        local code = (tool_err and tool_err.error) or policy.REASON.WORK_FAILURE
                        bounded_log("warn", { message = "openai_tool_effect_failed", error = code })
                        job:fail({ error = code })
                        return
                    end
                    messages[#messages + 1] = policy.tool_message(
                        parsed.id,
                        policy.tool_result_content(result.outcome, result.reason)
                    )
                end
            end
        end
    end

    -- Exhausted the turn budget without a final response.
    bounded_log("warn", { message = "openai_turn_budget_exhausted" })
    job:fail({ error = policy.REASON.TOOL_LOOP_EXHAUSTED })
end

-- ---------------------------------------------------------------------------
-- Worker loop: receive and process jobs serially.
-- ---------------------------------------------------------------------------
function agent.run_worker(queue, config)
    -- One volatile conversation per live worker generation, beginning with
    -- the configured system prompt. A restart or new worker starts
    -- system-only; only a successfully completed Job publishes its candidate
    -- conversation back, so failed Jobs never mutate prior context.
    local conversation = { policy.system_message(config.system_prompt) }
    while true do
        local job, err = queue:receive()
        if job == nil then
            -- Queue closed or unrecoverable error.
            if err and not policy.is_stop_error(err) then
                bounded_log("warn", {
                    message = "openai_worker_receive_failed",
                    error = err.error or "unknown",
                })
            end
            return
        end
        local ok, candidate = pcall(agent.process_job, job, config, conversation)
        if not ok then
            -- Unprotected Lua error: fail the job if possible.
            bounded_log("error", {
                message = "openai_worker_job_error",
                error = type(candidate) == "string" and candidate:sub(1, policy.MAX_REASON_BYTES) or "unknown",
            })
            pcall(function()
                job:fail({ error = policy.REASON.HOST_FAILURE })
            end)
        elseif type(candidate) == "table" then
            conversation = candidate
        end
    end
end

return agent
