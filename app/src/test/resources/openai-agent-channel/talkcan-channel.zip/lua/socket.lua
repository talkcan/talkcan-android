-- Package-local LuaSocket namespace shim (compatibility glue, not vendored).
--
-- The exact vendored `socket.url` module (LuaSocket 3.1.0) begins with
-- `local socket = require("socket")` and attaches itself as `socket.url`. The
-- real LuaSocket `socket` module loads the native `socket.core`, which is
-- prohibited here. This minimal pure-Lua namespace satisfies that single
-- `require("socket")` so the unmodified `socket.url` module can load and attach
-- itself. It provides no sockets, no TLS, no DNS, and no I/O of any kind; the
-- package performs all networking through `subspace.http` via the package-local
-- `socket.http` adapter. Nothing in the host reserves this ecosystem name.
return {
    _VERSION = "LuaSocket 3.1.0 (package-local namespace shim)",
}
