-- Thin shared wrapper around the vendored lua-openai client.
--
-- Both the one-shot model resolver and the durable worker construct a client
-- the same way: bind the unmodified lua-openai `OpenAI` class to a profile's
-- HTTPS base URL and API key, forcing the package-local `socket.http` provider
-- (never nginx, never a native socket, never a host SDK fallback). All
-- requests therefore flow: vendored client -> package socket.http adapter ->
-- talkcan.http. JSON flows through the package cjson adapter -> talkcan.json.
--
-- The wrapper performs no policy: it only builds the client and forwards the
-- non-streaming Chat Completions and Models operations. Transport failures
-- surface as Lua errors thrown by the vendored client's `assert`; callers pcall
-- and normalize them. Non-2xx statuses are returned to the caller as transport
-- successes.
local openai = require("openai")
local policy = require("policy")

local client = {}

-- Construct a vendored client for one profile. base_url is the profile's
-- bounded HTTPS origin (e.g. "https://api.openai.com/v1"); api_key is the
-- resolved protected secret plaintext.
function client.new(base_url, api_key)
    if not policy.bounded_string(base_url, policy.MAX_BASE_URL_BYTES) then
        return nil, { error = policy.REASON.INVALID_VALUE }
    end
    if not policy.bounded_string(api_key, policy.MAX_API_KEY_BYTES) then
        return nil, { error = policy.REASON.SECRET_UNAVAILABLE }
    end
    local instance = openai.OpenAI(api_key, { http_provider = "socket.http" })
    instance.api_base = base_url
    return instance, nil
end

-- Non-streaming Chat Completion. `messages` is the caller-owned conversation
-- array; `params` carries model/tools/parallel_tool_calls/temperature. Returns
-- (status, decoded_body, headers). Transport failures throw.
function client.chat(instance, messages, params)
    return instance:chat(messages, params)
end

-- GET /models. Returns (status, decoded_body, headers). Transport failures
-- throw.
function client.models(instance)
    return instance:models()
end

return client
