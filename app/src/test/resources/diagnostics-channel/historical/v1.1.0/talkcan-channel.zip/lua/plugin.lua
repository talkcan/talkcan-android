local runtime = require("subspace.runtime")
local log = require("subspace.log")
local channel = require("subspace.channel")

local release_marker = "1.1.0"

local function heartbeat_loop()
    local sequence = 0
    while true do
        sequence = sequence + 1
        log.info({
            event = "heartbeat",
            sequence = sequence,
            release_marker = release_marker
        })
        local ok, err = runtime.sleep(30.0)
        if not ok then
            break
        end
    end
end

local function startup()
    log.info({
        event = "startup",
        release_marker = release_marker
    })
    local ok, err = runtime.spawn(heartbeat_loop)
    if not ok then
        return {
            error = {
                code = "E_SPAWN_FAILED",
                detail = tostring(err and err.error or err)
            }
        }
    end
end

local function handle_lifecycle(event)
    local ready_event = channel.LIFECYCLE_READY or "ready"
    if not event or event.event ~= ready_event then
        return {
            error = {
                code = "E_LIFECYCLE",
                detail = "unexpected lifecycle event"
            }
        }
    end
    log.info({
        event = "ready",
        release_marker = release_marker
    })
end

local function handle_readiness()
    return { ready = true }
end

local function handle_input(event)
    local capture_event = channel.CAPTURE_COMPLETE or "capture"
    if not event or event.event ~= capture_event then
        return {
            error = {
                code = "E_INPUT",
                detail = "unexpected capture event"
            }
        }
    end
    local metadata = event.metadata
    if not metadata or type(metadata.duration_ms) ~= "number" or type(metadata.sample_rate) ~= "number" or type(metadata.channels) ~= "number" then
        return {
            error = {
                code = "E_INPUT_MALFORMED",
                detail = "malformed capture metadata"
            }
        }
    end
    log.info({
        event = "input",
        duration_ms = metadata.duration_ms,
        sample_rate_hz = metadata.sample_rate,
        channel_count = metadata.channels,
        release_marker = release_marker
    })
    return { ok = true }
end

local function handle_sos(event)
    local sos_event = channel.SOS_TRIGGERED or "sos"
    if not event or event.event ~= sos_event then
        return {
            error = {
                code = "E_SOS",
                detail = "unexpected SOS event"
            }
        }
    end
    log.info({
        event = "sos",
        release_marker = release_marker
    })
end

return {
    startup = startup,
    handle_lifecycle = handle_lifecycle,
    handle_readiness = handle_readiness,
    handle_input = handle_input,
    handle_sos = handle_sos,
}
